Creator
-------
.. automodule:: deap.creator

.. autofunction:: deap.creator.create(name, base[, attribute[, ...]])

.. autodata:: deap.creator.class_replacers